Contains all images
